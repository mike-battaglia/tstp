<?php
/**
 * Plugin Name:       Posts Table Pro Customizations
 * Plugin URI:        https://codeable.io/developers/yakubu-shehu
 * Description:       Extends functions of the Posts Table Pro plugin - allowing for customizations on table columns and data.
 * Author:            YS
 * Author URI:        https://codeable.io/developers/yakubu-shehu
 * Text Domain:       posts-table-pro-customizations
 * Version:           1.2.1
*/


// Define CONSTANTS
define( "PLUGIN_VERSION", get_plugin_data( __FILE__ )['Version'] );
define( "PLUGIN_DIR", plugin_dir_url( __FILE__ ) );
define( "FRONTEND_DATA", [
			'wpAjaxURL' => admin_url( 'admin-ajax.php' )
		]
);
// define( "RANDOM_NUMBER", rand(1,1000) ); // For debugging.


// Load AJAX Functions
add_action( 'wp_ajax_ptp_update_favorites', 'ptp_update_favorites' );
add_action( 'wp_ajax_nopriv_ptp_update_favorites', 'ptp_update_favorites' );

add_action( 'wp_ajax_ptp_get_note', 'ptp_get_note' );
add_action( 'wp_ajax_nopriv_ptp_get_note', 'ptp_get_note' );

add_action( 'wp_ajax_ptp_update_notes', 'ptp_update_notes' );
add_action( 'wp_ajax_nopriv_ptp_update_notes', 'ptp_update_notes' );



/* Enqueue Styles */
function ptp_customizations_enqueue_styles() {
	
	// Register and Enqueue the Posts Table Pro customizations styles.
	wp_enqueue_style( 'twenty-twenty-three-style', get_template_directory_uri() .'/style.css' );
	wp_enqueue_style( 'posts-table-pro-customizations', PLUGIN_DIR . 'assets/css/style.css', array(), PLUGIN_VERSION, 'all' );
	wp_enqueue_style( 'font-awesome',  PLUGIN_DIR . 'assets/css/vendor/font-awesome/css/all.css' );

}
add_action( 'wp_enqueue_scripts', 'ptp_customizations_enqueue_styles' );


/* Enqueue Scripts */
function ptp_customizations_enqueue_scripts() {
	
	// Register and Enqueue the Posts Table Pro customizations scripts.
	wp_enqueue_script( 'posts-table-pro-customizations', PLUGIN_DIR . 'assets/js/ptp-customizations-script.js', array('jquery'), PLUGIN_VERSION );
	wp_localize_script( 'posts-table-pro-customizations', 'ptp_customizations_frontend_data', FRONTEND_DATA );
	wp_enqueue_script( 'posts-table-pro-customizations' );


	// Add HTML code for overlay and other info elements.
	$loadingImgURL = PLUGIN_DIR . 'assets/img/loading.gif';

	// Notes Modal HTML
	$modalHTML = '<div class="modal-backdrop hide"></div>';

	$modalHTML .= '<div id="postsTableProNotesModal" class="ptpc-modal hide">';
	$modalHTML .= '<div class="modal-dialog">';
	$modalHTML .= '<div class="modal-content">';

	$modalHTML .= '<div class="modal-header post-notes-header">';
	$modalHTML .= '<p id="postNoteTitle" class="post-note-title"></p>';
	$modalHTML .= '<button role="button" type="button" data-post-id="" class="btn modal-close"><span><i class="fa fa-times"></i></span></button>';
	$modalHTML .= '</div>';

	$modalHTML .= '<div class="modal-body post-notes-details">';

	$modalHTML .= '<div id="postsTableProNotesLoadingOverlay" class="loading-overlay">';
	$modalHTML .= '<p id="loadingOverlayTitle">Loading...</p>';
	$modalHTML .= '<img src="' . $loadingImgURL . '" alt="loading-gif" draggable="false" />';
	$modalHTML .= '</div>';

	$modalHTML .= '<form action="" class="post-notes-form">';
	$modalHTML .= '<input id="currentNotePostID" name="current-note-post-id" type="hidden" value="" placeholder="" />';
	$modalHTML .= '<label for="post-note">Note(s):</label>';
	$modalHTML .= '<textarea id="postNote" name="post-note" type="textarea" rows="10" placeholder="Enter your note(s) here..." value=""></textarea>';
	$modalHTML .= '<button id="postNoteSubmit" role="button" type="button" data-post-id="" class="btn posts-table-pro-note-submit">Save <span><i class="fas fa-floppy-disk"></i></span></button>';
	$modalHTML .= '</form>';

	$modalHTML .= '</div>';

	$modalHTML .= '</div>';
	$modalHTML .= '</div>';
	$modalHTML .= '</div>';


	// Snackbar HTML
	$snackbarHTML = '<div class="ptpc-snackbar-wrapper">';
	$snackbarHTML .= '<div id="postsTableProSnackbar" class="ptpc-snackbar">';
	$snackbarHTML .= '</div>';
	$snackbarHTML .= '</div>';

	echo $modalHTML;
	echo $snackbarHTML;

}
add_action( 'wp_footer', 'ptp_customizations_enqueue_scripts', 10 );




/**
 * ======================================================
 * POSTS TABLE PRO - CUSTOMIZATIONS
 * ======================================================
 */

// Adding Data Classes For "Favorite" Column in Table.
function extend_ptp_classes() {
	
	if ( class_exists( 'Barn2\Plugin\Posts_Table_Pro\Data\Abstract_Table_Data' ) ) {
		
		// Initialize class and data for the 'Favorite' custom column in the posts table. 
		class Posts_Table_Favorite_Column extends Barn2\Plugin\Posts_Table_Pro\Data\Abstract_Table_Data { 
		
			public function get_data() {
				
				// Only display the favoriting checkbox if the user is logged in.
				if ( is_user_logged_in() ) {
				
					$user_id = get_current_user_id();
					$post_id = $this->post->ID;
					
					$meta_table_key = "table_favorites_" . get_post_type( $post_id );
				
					// Retrieve the user's favorite data from the meta table.
					$favorites_data = array();
					$favorites_usermeta = get_user_meta( $user_id, 'ptp_table_favorites', true );
					
					if ($favorites_usermeta && is_array($favorites_usermeta)) {
						$favorites_data = ($favorites_usermeta[$meta_table_key]) ? $favorites_usermeta[$meta_table_key] : array();
					}
					
					$checbox_html = '';
					
					$checbox_html = sprintf( '<input type="checkbox" id="checkbox_%1$s" name="checkbox_%1$s" value="%2$s" %3$s data-post-id="%1$s" class="parent posts-table-pro-checkbox checkbox_%1$s">',
						$post_id,
						esc_html( $this->post->post_title ),
						( in_array($post_id, $favorites_data) ) ? 'checked' : ''
					);
					return $checbox_html;
				}
				else {
					return '<small class="posts-table-pro-login-prompt">Login to add favorites.</small>';
				}
			}
		}

		// Initialize class and data for the 'Notes' custom column in the posts table.  
		class Posts_Table_Notes_Column extends Barn2\Plugin\Posts_Table_Pro\Data\Abstract_Table_Data { 

			public function get_data() {
			
				// Only display the note trigger button if the user is logged in.
				if ( is_user_logged_in() ) {
			
					$user_id = get_current_user_id();
					$post_id = $this->post->ID;
					$data_exists = false;
					
					$meta_table_key = "table_notes_" . get_post_type( $post_id );
				
					// Retrieve the user's note data from the meta table.
					$notes_data = array();
					$notes_usermeta = get_user_meta( $user_id, 'ptp_table_notes', true );
					
					// print_r($notes_usermeta); // For debugging
					
					if ($notes_usermeta && $notes_usermeta[$meta_table_key]) {
						$notes_data = ($notes_usermeta[$meta_table_key]) ? $notes_usermeta[$meta_table_key] : array();
					}
					
					$data_exists = ( isset($notes_data[$post_id]) && strlen($notes_data[$post_id]['note']) );
					
					// print_r($notes_data); // For debugging
					
					$notes_trigger_html = '';
					
					$notes_trigger_html = sprintf(
						'<div class="notes-actions-wrapper"><button role="button" type="button" data-post-id="%1$s" data-post-title="%2$s" class="btn parent posts-table-pro-notes note_button_%1$s %3$s"><span>%3$s <i class="%4$s"></i></span></button></div>',
						$this->post->ID,
						esc_html( $this->post->post_title ),
						( $data_exists ) ? 'edit' : 'add',
						( $data_exists ) ? 'fa fa-pencil' : 'fa fa-plus'
					);
					return $notes_trigger_html;
				}
				else {
					return '<small class="posts-table-pro-login-prompt">Login to add notes.</small>';
				}
			}
		}
		
	}
	
}
add_action('plugins_loaded', 'extend_ptp_classes');


// Add filter for 'Favourite' column data retrieval on table display.
add_filter( 'posts_table_custom_table_data_favorite', function( $obj, $post, $args ) { 
	return new Posts_Table_Favorite_Column( $post ); 
}, 99, 3 );


// Add filter for 'Favourite' column data retrieval on table display.
add_filter( 'posts_table_custom_table_data_notes', function( $obj, $post, $args ) { 
	return new Posts_Table_Notes_Column( $post ); 
}, 99, 3 );





// Function that updates the "favorite" data inside the _user_meta table.
function ptp_update_favorites() {
	
	$data = array();
	
	if ( is_user_logged_in() && isset($_POST['post_id']) ) {
		$user_id = get_current_user_id();
		$post_id_to_process = $_POST['post_id'];
		$post_type_to_process = get_post_type( $post_id_to_process );
		$meta_table_key = "table_favorites_" . $post_type_to_process;
		$is_meta_updated = false;
		$action = null;
		
		$new_favorite = null;
		$new_metadata = null;
		
		$current_metadata = get_user_meta( $user_id, 'ptp_table_favorites', true );
		
		// If favorites metadata does not exist in the table, create new favorites array.
		if( !$current_metadata ) {
			$current_metadata = array( $meta_table_key => array() );
		}
		
		$current_favorites = ($current_metadata[$meta_table_key]) ? $current_metadata[$meta_table_key] : array();
		
		// Remove from the array of favorites if already present inside favorites meta key.
		if( $current_favorites && in_array( $post_id_to_process, $current_favorites ) ) {
			$new_favorite = array_diff( $current_favorites, [$post_id_to_process] );
			$action = 'remove';
		}
		
		// Else, update existing array of favorites data by combining what was previously in the 'ptp_table_favorites' meta key
		// with the new ID of the post that needs to be added.
		else {
			$new_favorite = array_merge($current_favorites, array($post_id_to_process));
			$action = 'add';
		}
		
		$current_metadata[$meta_table_key] = $new_favorite;
		$new_metadata = $current_metadata;
		
		$is_meta_updated = update_user_meta( $user_id, 'ptp_table_favorites', $new_metadata);
		//$is_meta_deleted = delete_user_meta( $user_id, 'ptp_table_favorites'); // For Debugging
		
		// If meta has successfully been added, updated or removed:
		$data['status'] = ( $is_meta_updated ) ? 1 : 0;
		$data['action'] = $action;
		
		// echo json_encode($current_metadata[$meta_table_key]); // For Debuggin
		echo json_encode($data);
	}
	
	wp_die();
	
}



// Function that gets the "notes" data from inside the _user_meta table.
function ptp_get_note() {
	
	$data = array();
	
	if ( is_user_logged_in() && isset($_POST['post_id']) ) {
		$user_id = get_current_user_id();
		$post_id_to_process = $_POST['post_id'];
		$post_title_to_process = get_the_title($_POST['post_id']);
		$post_type_to_process = get_post_type( $post_id_to_process );
		$meta_table_key = "table_notes_" . $post_type_to_process;
		$is_meta_updated = false;
		$action = null;
		
		$current_metadata = get_user_meta( $user_id, 'ptp_table_notes', true );
		
		// update_user_meta( $user_id, 'ptp_table_notes', array()) ;
		
		// If favorites metadata does not exist in the table, create new favorites array.
		if( !$current_metadata ) {
			$current_metadata = array( $meta_table_key => array() );
		}
		
		$current_note = ($current_metadata[$meta_table_key]) ? $current_metadata[$meta_table_key][$post_id_to_process]['note'] : null;
		
		
		// If meta has successfully been retrieved:
		$data['status'] = ( $current_note != null ) ? 1 : 0;
		$data['title'] = $post_title_to_process;
		$data['note'] = $current_note;
		
		// echo json_encode($current_metadata[$meta_table_key]); // For Debuggin
		echo json_encode($data);
	}
	
	wp_die();
	
}




// Function that updates the "notes" data inside the _user_meta table.
function ptp_update_notes() {
	
	$data = array();
	
	if ( is_user_logged_in() && isset($_POST['post_id']) && isset($_POST['post_note']) ) {
		$user_id = get_current_user_id();
		$post_id_to_process = $_POST['post_id'];
		$post_note_to_process = trim(filter_var($_POST['post_note'], FILTER_SANITIZE_STRING, FILTER_FLAG_NO_ENCODE_QUOTES));
		$post_title_to_process = get_the_title($_POST['post_id']);
		$post_type_to_process = get_post_type( $post_id_to_process );
		$meta_table_key = "table_notes_" . $post_type_to_process;
		$is_meta_updated = false;
		$is_meta_diff = false;
		$action = null;
		
		$new_notes = null;
		$new_metadata = null;
		
		$current_metadata = get_user_meta( $user_id, 'ptp_table_notes', true );
		
		// If notes metadata does not exist in the table, create new notes array.
		if( !$current_metadata ) {
			$current_metadata = array( $meta_table_key => array() );
		}
		
		// Initialize new blank array if the notes sub-array doesn't exist in the metadata array from the database.
		$current_notes = ($current_metadata[$meta_table_key]) ? $current_metadata[$meta_table_key] : array();
		
		
		// If a note for a specific post exists in the metadata already, set the return action to "updated".
		// Else, set the return action to "added"
		$action = ( $current_notes && isset($current_notes[$post_id_to_process]) ) ? 'update' : 'add';
		
		
		$current_notes[$post_id_to_process]['note'] = $post_note_to_process;
		$new_notes = $current_notes;
		
		// Assign the current (unmodified) metadata from database to a temp metadata array.
		// Then update the notes values in the temp metadata array only.
		$new_metadata = $current_metadata;
		$new_metadata[$meta_table_key] = $new_notes;
		
		
		// Check if newly modified temp metadata array, is different from the existing metadata in the database.
		$is_meta_diff = ( serialize($new_metadata) == serialize($current_metadata) );
		
		
		$is_meta_updated = update_user_meta( $user_id, 'ptp_table_notes', $new_metadata );
		// $is_meta_deleted = delete_user_meta( $user_id, 'ptp_table_notes'); // For Debugging
		
		// If metadata has been successfully updated in the database, or the metadata arrays are exactly the same, or if there was an error:
		// Set the appropriate status and action.
		$data['status'] = ( $is_meta_updated || $is_meta_diff ) ? 1 : 0;
		$data['action'] = $action;
		
		// echo json_encode($current_metadata[$meta_table_key]); // For Debugging
		echo json_encode($data);
	}
	
	else {
		$data['status'] = 0;
		$data['action'] = 'failed';
		echo json_encode($data);
	}
	
	wp_die();
	
}




// Register a shortcode to display a Post Tables Pro list of posts that have been "favorited".
add_shortcode( 'my_favorites', 'display_favorites' );
function display_favorites( $atts ) {
	
	$shortcode_atts = shortcode_atts( array(
		'post_type' => null,
		'columns' => null,
		'column_breakpoints' => null,
	), $atts );
	
	$post_type_to_show = $shortcode_atts['post_type'];
	$table_columns_to_show = $shortcode_atts['columns'];
	$column_breakpoints = $shortcode_atts['column_breakpoints'];
	
	$favorite_html = '';

	// If the user isn't logged in
	if ( !is_user_logged_in() ) {
		$favorite_html = '<p class="mtb-large text-bold text-center">Please login to access your list of favorites...</p>';
		return $favorite_html;
	}

	// If a post type isn't specified.
	if ( !$post_type_to_show ) {
		$favorite_html = '<p class="mtb-large text-bold text-center">Please specify a post type to show...</p>';
		return $favorite_html;
	}
	
	// If the table columns aren't specified.
	if ( !$table_columns_to_show ) {
		$favorite_html = '<p class="mtb-large text-bold text-center">Please specify the table columns you would like to show...</p>';
		return $favorite_html;
	}
	
	
	
	/**
	 * -----------------------------------------------------------------------
	 * SCRAPPED.
	 * Post table query filter does not accept external variables.
	 * Trying to avoid the use of glolbal variables and PHP's Anonymous Functions
	 
		// The post type favorites value to look through in the nested array of favorite metadata.
		$post_type_meta_value = 'table_favorites_' . $post_type_to_show;
		
		$current_metadata = get_user_meta( get_current_user_id(), 'ptp_table_favorites', true );
		
		$favorites_for_post_type = $current_metadata[$post_type_meta_value];
		
		
		// print_r($favorites_for_post_type); // For debugging.
		// print_r(serialize($favorites_for_post_type)); // For debugging.
		
		
		if ($favorites_for_post_type && is_array($favorites_for_post_type)) {
			add_filter( 'posts_table_query_args', function( $args, $query ) {
				// do something with $args
				
				// Generate custom query args to only fetch posts that have their post ID present in the 'ptp_table_favorites' user_meta.
				$favorite_query_args = array(
					'post_type' => $post_type_to_show,
					'post__in' 	=> $favorites_for_post_type
				);
				
				$args = $favorite_query_args;
				return $args;
			}, 10, 2 );
		}
	* -----------------------------------------------------------------------
	*/
	
	
	// CONTRACTOR DATA:
	// If dealing with the "Contractor Data" post type.
	if ( $post_type_to_show == 'contractor-data' ) {
		
		//MBATT: Check is user meta exists
		$mbatt_user_meta = get_user_meta( get_current_user_id(), 'ptp_table_favorites', true );
		//$mbatt_check_faves_exist = is_array($mbatt_user_meta) && isset($mbatt_user_meta['table_favorites_contractor-data']) ? $mbatt_user_meta['table_favorites_contractor-data'] : false;
		$favorite_post_ids = is_array($mbatt_user_meta) && isset($mbatt_user_meta['table_favorites_contractor-data']) ? $mbatt_user_meta['table_favorites_contractor-data']: '';
		
		
		//ORIGINAL: $favorite_post_ids = get_user_meta( get_current_user_id(), 'ptp_table_favorites', true )['table_favorites_contractor-data'];
		
		// If any posts IDs exist in the usermeta's favorite for 'contractor-data', then run query filter for table posts.
		if ( !empty( $favorite_post_ids ) ) {
			
			add_filter( 'posts_table_query_args', function( $args, $query ) {
				
				// Generate custom query args to only fetch posts that have their post ID present in the 'ptp_table_favorites' user_meta for contractor-data.
				$favorite_query_args = array(
					'post_type' => 'contractor-data',
					'post__in' 	=> get_user_meta( get_current_user_id(), 'ptp_table_favorites', true )['table_favorites_contractor-data'],
					'posts_per_page' => -1,
				);
				
				return $favorite_query_args;
			}, 10, 2 );
			
		}
		else {
			$favorite_html = '<h1 class="text-center">Nothing to see here!</h1><p class="mtb-large text-bold text-center">Start browsing the <a href="/contractors-taxability-and-certificates-guide/"><u>taxability charts</a></u> and saving your favorites. They\'ll be here when you come back.</p>';
			return $favorite_html;
		}
	}
	
	
	// TAXES DATA:
	// If dealing with the "Taxes" post type.
	else if ( $post_type_to_show == 'taxes' ) {
		
		//MBATT: Check is user meta exists
		$mbatt_user_meta = get_user_meta( get_current_user_id(), 'ptp_table_favorites', true );
		//$mbatt_check_faves_exist = is_array($mbatt_user_meta) && isset($mbatt_user_meta['table_favorites_taxes']) ? $mbatt_user_meta['table_favorites_taxes'] : false;
		$favorite_post_ids = is_array($mbatt_user_meta) && isset($mbatt_user_meta['table_favorites_taxes']) ? $mbatt_user_meta['table_favorites_taxes']: '';
		
		//ORIGINAL: $favorite_post_ids = get_user_meta( get_current_user_id(), 'ptp_table_favorites', true )['table_favorites_taxes'];
		
		// If any posts IDs exist in the usermeta's favorite for 'taxes', then run query filter for table posts.
		if ( !empty( $favorite_post_ids ) ) {
			
			add_filter( 'posts_table_query_args', function( $args, $query ) {
				
				// Generate custom query args to only fetch posts that have their post ID present in the 'ptp_table_favorites' user_meta for taxes.
				$favorite_query_args = array(
					'post_type' => 'taxes',
					'post__in' 	=> get_user_meta( get_current_user_id(), 'ptp_table_favorites', true )['table_favorites_taxes'],
					'posts_per_page' => -1,
				);
				
				return $favorite_query_args;
			}, 10, 2 );
			
		}
		else {
			$favorite_html = '<h1 class="text-center">Nothing to see here!</h1><p class="mtb-large text-bold text-center">Start browsing the <a href="/tax-book-search-page/"><u>taxability charts</a></u> and saving your favorites. They\'ll be here when you come back.</p>';
			return $favorite_html;
		}
	}

	// Generate Posts Table Pro table using shortcode containing the corresponding columns for this post type.
	$favorite_html = '';
	if ( $post_type_to_show != 'taxes' ) {
		$favorite_html = do_shortcode('[posts_table post_type="' . $post_type_to_show .'" columns="' . $table_columns_to_show . '" lazy_load="false" filters="true" sort_by="content" sort_order="asc" column_breakpoints="' . $column_breakpoints . '"]');
	} else {
		$favorite_html = do_shortcode('[posts_table post_type="' . $post_type_to_show .'" columns="' . $table_columns_to_show . '" lazy_load="false" filters="true" sort_by="content" sort_order="asc"]');
	}
	return $favorite_html;
	
}
