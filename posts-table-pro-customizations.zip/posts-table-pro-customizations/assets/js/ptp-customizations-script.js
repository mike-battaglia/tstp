 (function($) {
	 
	// console.log('loaded ptp customizations script...') // For debugging.
	 
	var snackbarElem = $('#postsTableProSnackbar');
	var snackbarTimeoutID;
	var searchHighlightTimeoutID;
	var searchActivity = false;
	
	
	$('.posts-data-table').on('draw.dt', function() {
		// console.log( 'DataTable redrawn.' ); // For debugging.
		initMainListeners();
		
		searchActivity = false;
		
		// If redrawn on a search trigger.
		searchActivity = ($('.dataTables_filter input').val().length > 0) ? true : false;
		clearTimeout(searchHighlightTimeoutID);
		
		if ( searchActivity !== null && searchActivity === true ) {
			searchHighlightTimeoutID = setTimeout(function() {
				// console.log('A search just happened... Initializing search results highlight.'); // For debugging.
				initSearchResultsHighlight();
			}, 500);
		}
	});
	
	/**DEPRICATED
	// Highlight all matching search results text containing the keyword entered in the search bar.
	function initSearchResultsHighlight() {
		var searchBarElem = $('.dataTables_filter input');
		var ptpSearchTerm = null;
				
		if ( searchBarElem && searchBarElem.val().length > 0 ) {
			ptpSearchTerm = searchBarElem.val();
			
			// console.log( "Keyword Searched For --> " + ptpSearchTerm ); // For debugging.
			
			var tableCellNodes = $('.posts-data-table tbody td');
			
			var keywordNodes = tableCellNodes.filter(function() {
				return $(this).text().toLowerCase().includes(ptpSearchTerm);
			});
			
			$.each(keywordNodes, function(index, node) {
				var originalString = $(node).text();
				var regexPattern = new RegExp( ptpSearchTerm, 'ig' );
				$(node).html( originalString.replace(regexPattern, function(match) {
					return `<span class='ptp-search-term highlighted'>${match}</span>`; 
				}));
			});
		}
	}
	 DEPRICATED**/
	 
	// Highlight all matching search results text containing the keyword entered in the search bar.
	function initSearchResultsHighlight() {
		console.log('🟢 Initializing search results highlight...'); // For debugging.
		var searchBarElem = $('.dataTables_filter input');
		var ptpSearchTerm = null;
				
		if ( searchBarElem && searchBarElem.val().length > 0 ) {
			ptpSearchTerm = searchBarElem.val();
			
			// console.log( "Keyword Searched For --> " + ptpSearchTerm ); // For debugging.
			
			var tableCellNodes = $('.posts-data-table tbody td');
			
			var keywordNodes = tableCellNodes.filter(function() {
				return $(this).text().toLowerCase().includes(ptpSearchTerm);
			});
			
			// Deconfliction: Preserve anchor tags while highlighting search matches.
			$.each(keywordNodes, function(index, node) {
				var originalString = $(node).html();
				var regexPattern = new RegExp( ptpSearchTerm, 'ig' );
				$(node).html( originalString.replace(regexPattern, function(match, offset, fullString) {
					// Check if the match is inside an anchor tag
					var isInAnchorTag = fullString.slice(0, offset).lastIndexOf("<a") > fullString.slice(0, offset).lastIndexOf("</a");
					if (isInAnchorTag) {
						// If the match is inside an anchor tag, return it without changes
						return match;
					} else {
						// If the match is not inside an anchor tag, return it wrapped in the span tag
						return `<span class='ptp-search-term highlighted'>${match}</span>`;
					}
				}));
			});
		}
	}
	
	
	// Attach/initialize the favorite-checkbox and note-button listeners.
	function initMainListeners() {
		
		// When the favorite checkbox is clicked.
		$('.posts-table-pro-checkbox').on('change', function(e) {
			
			e.preventDefault;
			clearTimeout(snackbarTimeoutID);
			
			let elemID = $(this).attr('id');
			let elemTitle = $(this).val();
			let fPID = $(this).attr('data-post-id');
			var currentState = $(this).prop('checked');
			
			// Disable all matching checkbox divs.
			checkboxDivs = $(`.${elemID}`);
			checkboxDivs.each(function(checkboxDiv) {
				
				// console.log($(this)); // For debugging.
				
				$(this).attr("disabled", true);
			});
			
			// Set matching state (checked/unchecked) fro all matching checkbox divs.
			checkboxDivs.each(function(checkboxDiv) {
				$(this).prop('checked', currentState);
			});
			
			ptpUpdateFavorites(fPID, elemID);
			
		});
	
	
		// When the note trigger (add or update) button is clicked.
		$('.btn.posts-table-pro-notes').on('click', function(e) {
			let nPID = $(this).attr('data-post-id');
			// let nPTitle = $(this).attr('data-post-title');
			let nPTitle = $(this).attr('data-post-title');
			
			var modalTitle = (nPTitle !== undefined) ? nPTitle.split("-")[0] : "";
			$('#postNoteTitle').html(modalTitle);
			
			showModalBox(nPID);
		});
	}
	
	
	// When the modal close button is clicked.
	$('.btn.modal-close').on('click', function(e) {
		resetModalBox();
	});
	
	
	// When the note-saving button is clicked.
	$('#postNoteSubmit').on('click', function(e) {
		
		e.preventDefault;
		clearTimeout(snackbarTimeoutID);
		
		let nsPID = ($(this).attr('data-post-id')) ? $(this).attr('data-post-id') : $('#currentNotePostID').val();
		let nsText = $('#postNote').val();
		
		$(this).prop("disabled", true);
		
		// console.log(nsPID); // For debugging.
		// console.log(nsText); // For debugging.
		
		ptpUpdateNotes(nsPID, nsText);
	});
	
	
	// USES: Mutation Observer
	// Listen for when new data has been added to the table using after fetching data from the database.
	// And then attaches the event listeners to the new elements.
	// Helps with Lazy Loaded posts.
	function initMutationObserver() {
		let elemToObserve = document.querySelector('.posts-data-table');
		
		if (elemToObserve !== undefined) {
			
			var mObserver = new MutationObserver(function(mutations) {
				mutations.forEach(function(mutation) {
					
					// console.log(mutation) // For debugging.
					
					if (mutation.addedNodes && mutation.addedNodes.length > 0) {
						
						// console.log(mutation.addedNodes); // For debugging.
						
						// Check if the newly added DOM element is of class: "post-row".
						[].some.call(mutation.addedNodes, function(el) {
							if (el.classList.contains('post-row')) {
								
								// console.log(el); // For debugging.
								
								initMainListeners();
							}
						});
					}
				});
			});

			var observerConfig = {
				attributes: true,
				childList: true,
				characterData: true,
				subtree: true
			};

			mObserver.observe(elemToObserve, observerConfig);
		}
	}
	
	
	// USES: Mutation Observer
	// Listen for when new Post Table Pro columns have been added (as child elements) to the table when it is in respnsive mode.
	// And then reinitialize new event listeners to for the newly added elements.
	function initResponsiveMutationObserver() {
		let rElemToObserve = document.querySelector('.posts-data-table');
		
		if (rElemToObserve !== undefined) {
			
			var rMutatationObserver  = new MutationObserver(function(mutations) {
			
				if (searchActivity !== null && searchActivity === true) {
					// console.log('Posts Table Pro table mutated, but mutated on a search result highlight... Do nothing.'); // For debugging.
					return;
				}
				
				mutations.forEach(function(mutation) {
					
					// console.log(mutation) // For debugging.
					
					if (mutation.addedNodes && mutation.addedNodes.length > 0) {
						
						// console.log(mutation.addedNodes); // For debugging.
						
						// Check if the newly added DOM element is of class: "child".
						[].some.call(mutation.addedNodes, function(el) {
							if (el.classList.contains('child')) {
								
								// console.log(el); // For debugging.
								
								// Match state of parent favorite checkbox state to the newly added child favorite checkbox.
								var childCheckboxDiv = el.querySelector('.posts-table-pro-checkbox');
								
								if ( childCheckboxDiv !== null && childCheckboxDiv !== undefined ) {
								
									var childCheckboxID = childCheckboxDiv.getAttribute('data-post-id');
									childCheckboxDiv.classList.remove('parent');
									childCheckboxDiv.classList.add('collapsed');
									
									var parentCheckboxDiv = document.querySelector(`.parent.posts-table-pro-checkbox.checkbox_${childCheckboxID}`);
									var parentCheckboxState = parentCheckboxDiv.checked;
									childCheckboxDiv.checked = parentCheckboxState;
									
									childCheckboxDiv.addEventListener('change', function(e) {
										e.preventDefault;
										parentCheckboxDiv.click();
									});
									
								}
								
								
								// Match text of parent note trigger button to the newly added child note trigger button.
								var childNoteButtonDiv = el.querySelector('.posts-table-pro-notes');
								
								if ( childNoteButtonDiv !== null && childNoteButtonDiv !== undefined ) {
								
									var childNoteButtonID = childNoteButtonDiv.getAttribute('data-post-id');
									childNoteButtonDiv.classList.remove('parent');
									childNoteButtonDiv.classList.add('collapsed');
									
									var parentNoteButtonDiv = document.querySelector(`.parent.posts-table-pro-notes.note_button_${childNoteButtonID}`);
									var parentNoteButtonText = parentNoteButtonDiv.innerHTML;
									childNoteButtonDiv.innerHTML = parentNoteButtonText;
									
									childNoteButtonDiv.addEventListener('click', function(e) {
										e.preventDefault;
										parentNoteButtonDiv.click();
									});
									
								}
								
								
								// initMainListeners();
							}
						});
					}
				});
			});

			var rObserverConfig = {
				attributes: true,
				childList: true,
				characterData: true,
				subtree: true
			};

			rMutatationObserver.observe(rElemToObserve, rObserverConfig);
		}
	}
	
	
	
	// USES: Ajax
	// Function to update (add or remove) an item from the list of saved favorites.
	function ptpUpdateFavorites(postID, checkboxID) {

		if(postID !== undefined && checkboxID !== undefined) {

			var checkboxDivs = $(`.${checkboxID}`);
			var pFavoriteTitle = $(checkboxDivs[0]).val();
			let favoriteErrorMessage = `Failed to add/remove <strong>${pFavoriteTitle }</strong> to/from your favorites. Please try again later.`;

			$.ajax({
				type: 'POST',
				url: ptp_customizations_frontend_data.wpAjaxURL, 
				data: {
					action: 'ptp_update_favorites',
					post_id: postID,
				},
				// When an item from the list of saved favorites has been added or removed, print a success message notification.
				success: function(response){
					var rsp = JSON.parse(response);
					if(rsp !== undefined && rsp.status === 1) {
						var action = (rsp !== undefined) ? rsp.action : '';

						var actionVerb = (action === 'add') ? 'added' : 'removed';
						var actionPreposition = (action === 'add') ? 'to' : 'from';
						
						var snackbarMessage = `Successfully ${actionVerb} <strong>${pFavoriteTitle }</strong> ${actionPreposition} your favorites.`;
						
						showSnackbar(snackbarMessage, "success");
					}
				},
				// Upon failure, undo whatever state the button is in, and print an error message notification.
				fail: function(xhr, errorThrown, response) {
					
					checkboxDivs.each(function(checkboxDiv) {
						$(this).prop('checked', function(){
							return checkboxDiv.is(':checked') ? false : true;
						});
					});
					
					showSnackbar(favoriteErrorMessage, "error");
					console.log("AJAX Failure on Favoriting Function --- Reason for failure: " + response);
				},
				error: function(xhr, errorThrown, response) {
					
					checkboxDivs.each(function(checkboxDiv) {
						$(this).prop('checked', function(){
							return checkboxDiv.is(':checked') ? false : true;
						});
					});
					
					showSnackbar(favoriteErrorMessage, "error");
					console.log("AJAX Error on Favoriting Function --- Reason for error: " + response);
				},
				
			}).done(function(data) {
				checkboxDivs.each(function(checkboxDiv) {
					
					// console.log($(this));  // For debugging.
					
					$(this).removeAttr('disabled');
				});
			});
		}
	}
	
	
	// Function to show a popup notification with a message and matching class/style.
	function showSnackbar( message='', type='error') {
		
		if(snackbarElem !== undefined) {
			
			if(type === 'success') {
				snackbarElem.addClass('show success').removeClass('error');
			}
			
			else {
				snackbarElem.addClass('show error').removeClass('success');
			}
			
			snackbarElem.html(message);
			
			snackbarTimeoutID = setTimeout(function() {
				snackbarElem.removeClass("show");
			}, 3000);
		}
		
	}
	
	
	// USES: Ajax
	// Function to retrieve the stored notes of a particular item, and display the notes (if any) in a modal box.
	function ptpGetNoteDetails(postID) {
		
		var pNoteText;
		var pNoteTitle = $('#postNoteTitle').text();
		let getNoteErrorMessage = `Failed to retrieve note details for <strong>${pNoteTitle}</strong>. Please try again later.`;
		
		if(postID !== undefined) {
			$.ajax({
				type: 'POST',
				url: ptp_customizations_frontend_data.wpAjaxURL, 
				data: {
					action: 'ptp_get_note',
					post_id: postID,
				},
				success: function(response){
					var rsp = JSON.parse(response);
					if(rsp !== undefined) {
						
						// console.log(rsp); // For debugging.
						
						if (rsp.status === 1) {
							pNoteText = rsp.note;
						}
					}
				},
				fail: function(xhr, errorThrown, response) {
					console.log("AJAX Failure on Note Retrieval Function --- Reason for failure: " + response);
					showSnackbar(getNoteErrorMessage, "error");
				},
				error: function(xhr, errorThrown, response) {
					console.log("AJAX Failure on Note Retrieval Function --- Reason for error: " + response);
					showSnackbar(getNoteErrorMessage, "error");
				}
			}).done(function(data) {
				$('#postsTableProNotesLoadingOverlay').removeClass('show').addClass('hide');
				$('#currentNotePostID').val(postID);
				$('#postNoteSubmit').attr('data-post-id', postID);
				$('#postNote').val(pNoteText);
			});
		}
	}
	
	
	
	// USES: Ajax
	// Function used to either store a new note or update an existing note of a particular item; in a modal box.
	function ptpUpdateNotes(postID, postNote) {
		
		$('#loadingOverlayTitle').html('Saving Note...');
		$('#postsTableProNotesLoadingOverlay').removeClass('hide').addClass('show').css('opacity', 0.8);
		
		var pNoteLength = postNote.trim().length;
		
		var pNoteButtonTrigger = $(`.btn.posts-table-pro-notes[data-post-id=${postID}]`);
		var pNoteTitle = $('#postNoteTitle').text();
		let updateNoteErrorMessage = `Failed to update note details for <strong>${pNoteTitle}</strong>. Please try again later.`;

		if(postID !== undefined && postNote !== undefined) {

			$.ajax({
				type: 'POST',
				url: ptp_customizations_frontend_data.wpAjaxURL, 
				data: {
					action: 'ptp_update_notes',
					post_id: postID,
					post_note: postNote,
				},
				success: function(response){
					
					// console.log(response); // For debugging.
					
					var rsp = JSON.parse(response);
					
					if(rsp !== undefined && rsp.status === 1) {
						var action = (rsp !== undefined) ? rsp.action : '';
						
						var actionVerb = (action === 'add') ? 'added' : 'updated';
						
						var snackbarMessage = `Successfully ${actionVerb} your note for <strong>${pNoteTitle}</strong>.`;
						
						showSnackbar(snackbarMessage, "success");
						
						// If note that has been added is not empty.
						if(pNoteLength > 0 && pNoteButtonTrigger !== undefined) {
							// If note has been added, and button trigger text was previously "add", change the note trigger button text accordingly.
							if (pNoteButtonTrigger.hasClass('add')) {
								pNoteButtonTrigger.addClass('edit').removeClass('add').html('<span>edit <i class="fa fa-pencil"></i></span>');
							}
						}
						else {
							pNoteButtonTrigger.addClass('add').removeClass('edit').html('<span>add <i class="fa fa-plus"></i></span>');
						}
					}
				},
				fail: function(xhr, errorThrown, response) {
					console.log("AJAX Failure on Note Saving Function --- Reason for failure: " + response);
					showSnackbar(updateNoteErrorMessage, "error");
				},
				error: function(xhr, errorThrown, response) {
					console.log("AJAX Failure on Note Saving Function --- Reason for error: " + response);
					showSnackbar(updateNoteErrorMessage, "error");
				},
				
			}).done(function(data) {
				$('#postNoteSubmit').prop("disabled", false);
				$('#postsTableProNotesLoadingOverlay').removeClass('show').addClass('hide').css('opacity', 1);
				resetModalBox();
			});
		}
	}
	
	
	function showErrorMessage() {
		$('#postsTableProNotesLoadingOverlay').removeClass('d-block').addClass('d-none');
		$('.modal-body.product-details-container').html('<div class="modal-error-message-wrapper"><h2><i class="fa fa-search-minus fa-3x mb-5"></i></h2><h2>Failed to load product details...</h2><p>Please try again later</p></div>');
		$('.modal-body.product-details-container').removeClass('d-none').addClass('d-block');
	}
	
	
	// Function used to open/trigger the modal box into view/display.
	function showModalBox(pID) {
		$('body').addClass('modal-open');
		$('.modal-backdrop').removeClass('hide').addClass('show');
		$('#postsTableProNotesModal').removeClass('hide').addClass('show');
		$('#loadingOverlayTitle').html('Loading...');
		$('#postsTableProNotesLoadingOverlay').removeClass('hide').addClass('show');
		$('.modal-body.post-notes-details-container').empty();
		ptpGetNoteDetails(pID);
	}
	
	// Function used to close/clear the modal box from view/display.
	function resetModalBox() {
		$('body').removeClass('modal-open');
		$('.modal-backdrop').removeClass('show').addClass('hide');
		$('#postsTableProNotesModal').removeClass('show').addClass('hide');
		$('#postsTableProNotesLoadingOverlay').removeClass('show').addClass('hide');
		$('.modal-body.post-notes-details-container').empty();
	}
	
	
	
	// Initialize main listeners.
	initMainListeners();
	
	// Listen for when new child elements are added to the table in responsive mode.
	initResponsiveMutationObserver();
	
})(jQuery)
